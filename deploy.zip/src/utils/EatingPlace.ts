type EatingPlace = {
  name: string
  address: string
  website: string
  id: string
}

export default EatingPlace
