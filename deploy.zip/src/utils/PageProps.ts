type PageProps = {
  openSuccessSnackbar: ((message: string) => void)
  openFailureSnackbar: ((message: string) => void)
}

export default PageProps
